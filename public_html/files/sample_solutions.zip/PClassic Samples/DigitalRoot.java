public class DigitalRoot {
  public static int digitalRoot (int x) {
    assert (x >= 0);
    int root = 0;
    while (x > 0) {
      root += x % 10;
      x = x / 10;
    }

    if (root < 10) return root;
    else return digitalRoot (root);
  }
}