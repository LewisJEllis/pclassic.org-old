public class CashRegister {
    public static int[] getChange (int price, int paid) {
	assert (price <= paid);
	int[] currency = { 2000, 1000, 500, 100, 25, 10, 5, 1 };
	int[] change = new int[currency.length];
	int amountLeft = paid - price;

	for (int i = 0; i < change.length; i++) {
	    while (amountLeft >= currency[i]) {
		amountLeft -= currency[i];
		change[i]++;
	    }
	}

	return change;
    }
}