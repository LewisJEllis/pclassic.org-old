import java.util.LinkedList;
import java.util.ArrayList;

public class DrivingInTheSnow {
  public static boolean canGather(String input) {
    String[] parts = input.split(";");
    int n = Integer.parseInt(parts[0]);

    ArrayList<LinkedList<Integer>> neighbors = new ArrayList<LinkedList<Integer>>();
    for (int i = 0; i < n; i++)
      neighbors.add(new LinkedList<Integer>());
    for (int i = 1; i < parts.length; i++) {
      String[] edge = parts[i].split(",");
      neighbors.get(Integer.parseInt(edge[0])).add(Integer.parseInt(edge[1]));
    }
    
    boolean[] seen = new boolean[n];
    LinkedList<Integer> q = new LinkedList<Integer>();
    q.add(0);
    seen[0] = true;
    int seenCount = 1;
    while (!q.isEmpty() && seenCount < n) {
      int v = q.pop();
      for (int neighbor : neighbors.get(v)) {
        if (!seen[neighbor]) {
          q.add(neighbor);
          seen[neighbor] = true;
          seenCount++;
        }
      }
      seen[v] = true;
    }

    return ((n == seenCount) ? 1 : 0);
  }
  
  public static void main(String[] args) {
    for (int i = 0; i < args.length; i++) {
      System.out.println(args[i]);
      System.out.println(DrivingInTheSnow.canGather(args[i]));
    }
  }
}