public class PolygonContainment {
  private static boolean intersects(int[] v, int[] v1, int[] v2) {
    if ((v[1] > v1[1] && v[1] < v2[1])) {
      return ((v2[0] - v1[0])*(v[1] - v1[1]) - (v2[1] - v1[1])*(v[0] - v1[0]) > 0);
    } else if ((v[1] < v1[1] && v[1] > v2[1])) {
      return ((v2[0] - v1[0])*(v[1] - v1[1]) - (v2[1] - v1[1])*(v[0] - v1[0]) < 0);
    } else {
      return false;
    }
  }

  public static int contains(String input) {
    // Parse the input:
    String[] polygons = input.split(":");
    String[] p1 = polygons[0].split(";");
    String[] p2 = polygons[1].split(";");

    int[][] p1v = new int[p1.length][];
    int[][] p2v = new int[p2.length][];
    for (int i = 0; i < p1.length; i++) {
      String[] v = p1[i].split(",");
      p1v[i] = new int[2];
      p1v[i][0] = Integer.parseInt(v[0]);
      p1v[i][1] = Integer.parseInt(v[1]);
    }
    for (int i = 0; i < p2.length; i++) {
      String[] v = p2[i].split(",");
      p2v[i] = new int[2];
      p2v[i][0] = Integer.parseInt(v[0]);
      p2v[i][1] = Integer.parseInt(v[1]);
    }
    // Check for containment:
    for (int[] v : p1v) {
      int c = 0;
      for (int i = 0; i < p2v.length; i++) {
        int[] v1 = p2v[i];
        int[] v2 = p2v[((i+1 != p2v.length) ? i+1 : 0)];
        if (intersects(v,v1,v2))
          c++;
      }
      if (c % 2 == 0)
        return 0;
    }
    return 1;
  }
  
  public static void main(String[] args) {
    for (int i = 0; i < args.length; i++) {
      System.out.println(args[i]);
      System.out.println(PolygonContainment.contains(args[i]));
    }
  }
}

/*
Algorithm pseudocode:
for each vertex in p1
  count = 0
  for each edge in p2
    if horizontal line through vertex intersects edge to right of vertex
      count++
  if count % 2 == 0
    return false
return true
*/