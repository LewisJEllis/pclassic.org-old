import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TreeSet;


public class Anagrams {
	public static int solve(int n, String k, List<String> dictionary){
		
		
		return -1; //replace this with the solution
	}
	
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("anagrams.txt"));
		boolean readingDictionary = true;
		ArrayList<String> dictionary = new ArrayList<String>();
		while(br.ready()){
			String line = br.readLine();
			if(readingDictionary){
				if(line.equals("***END***")){
					readingDictionary = false;
					continue;
				}
				if(line.length() < 9 && line.length() > 2){
					dictionary.add(line.toUpperCase());
				}
			} else{
				String[] split	= line.split(" ");
				int n = Integer.parseInt(split[0]);
				String k = split[1];
				System.out.println(solve(n, k, dictionary));
			}
		}
	}
	
}
