import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public class PalindromeSearch {
    
    public static String longestPalindrome(String s) {

        return null; //replace this with the solution
    }
    
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("palindromesearch.txt"));
		while(br.ready()){
			String line = br.readLine();
			System.out.println(longestPalindrome(line));
		}
	}
}
