import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;


public class Lucky {
	
	public static boolean isLucky(int number){
		return false; //replace this with the solution
	}
	
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("lucky.txt"));
		while(br.ready()){
			String line = br.readLine();
			int val = Integer.parseInt(line);
			System.out.println(isLucky(val));
		}
	}
}
