import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class SumsOfDigits {

	public static int PQOverlaps(int n){

		return 0; //replace this with the solution
		
	}
	
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("sumsofdigits.txt"));
		while(br.ready()){
			String line = br.readLine();
			int val = Integer.parseInt(line);
			System.out.println(PQOverlaps(val));
		}
	}
	
}
