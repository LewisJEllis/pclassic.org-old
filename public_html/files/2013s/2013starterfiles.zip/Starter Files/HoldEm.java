import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.TreeSet;


public class HoldEm {
	
	public static boolean p1wins(String player1, String player2, String community){
		
		return false; //replace this with the solution
	}
	
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("holdem.txt"));
		while(br.ready()){
			String p1 = br.readLine();
			String p2 = br.readLine();
			String community = br.readLine();
			System.out.println(p1wins(p1, p2, community));
		}
	}
}