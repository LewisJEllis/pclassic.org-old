import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class SpiralDiagonal {
	public static int sum (int N){
		return 0; //replace this with the solution
	}
	
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("spiral.txt"));
		while(br.ready()){
			String line = br.readLine();
			int val = Integer.parseInt(line);
			System.out.println(sum(val));
		}
	}
}
