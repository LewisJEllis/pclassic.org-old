import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;


public class Next {

	public static String getNext(String str){
		return null;
	}
	
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("next.txt"));
		while(br.ready()){
			String line = br.readLine();
			System.out.println(getNext(line));
		}
	}
}
