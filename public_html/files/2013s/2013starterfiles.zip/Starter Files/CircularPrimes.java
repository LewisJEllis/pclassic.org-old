import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CircularPrimes {

	public static boolean isCircular(long number){
		
		
		return false; //replace this with the solution
	}
	
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("circularprimes.txt"));
		while(br.ready()){
			String line = br.readLine();
			long val = Integer.parseInt(line);
			System.out.println(isCircular(val));
		}
	}
}
