import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class AdditionExponent {

    /* 
    Only the body of this method must be completed; the rest is provided.
    
    Given a positive integer base and nonnegative integer exponent,
    calculate the base raised to the exponent with only addition.
    */
    public static int solve(int base, int exponent) {
        int ret = 1;
        for (int i = 0; i < exponent; i++) {
            int prod = 0;
            for (int j = 0; j < base; j++) {
                prod += ret;
            }
            ret = prod;
        }
        return ret;
    }

    public static void main(String [] args) throws IOException{
        BufferedReader br = new BufferedReader(new FileReader("additionexponent.txt"));
        while (br.ready()) {
            String line = br.readLine();
            String[] parts = line.split(" ");
            int base = Integer.parseInt(parts[0]);
            int exponent = Integer.parseInt(parts[1]);
            System.out.println(solve(base, exponent));
        }
    }

}
