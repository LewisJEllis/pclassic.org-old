import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Palindrome {

    /* 
    Only the body of this method must be completed; the rest is provided.

    Given a string of words separated by spaces,
    determine how many of those words are palindromes
    */
    public static int solve(String words) {
        String[] wordlist = words.split(" ");
        int count = 0;

        for (String word : wordlist) {
            int len = word.length();
            boolean flag = true;

            for (int i = 0; i < len / 2; i++) {
                if (word.charAt(i) != word.charAt(len - i - 1)) {
                    flag = false;
                    break;
                }
            }

            if (flag) count += 1;
        }

        return count;
    }



    public static void main(String [] args) throws IOException{
        BufferedReader br = new BufferedReader(new FileReader("palindrome.txt"));
        while (br.ready()) {
            String line = br.readLine();
            System.out.println(solve(line));
        }
    }

}
